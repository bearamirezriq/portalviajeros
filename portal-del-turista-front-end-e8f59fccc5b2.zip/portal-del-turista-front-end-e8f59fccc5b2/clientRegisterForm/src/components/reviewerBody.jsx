/*- reviewerBody.jsx -*/

import React from 'react';
import { DataGrid } from '@mui/x-data-grid';

class Body extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
        eventColumns : [
          { field: 'id', headerName: 'ID', width: 70 },
          { field: 'eventName', headerName: 'Event name', width: 130 },
          { field: 'eventDesc', headerName: 'Description', width: 130 },
          { field: 'eventSponsor', headerName: 'Sponsor', width: 130 },
          { field: 'eventPreference', headerName: 'Preference', width: 130},
          { field: 'eventDuration', headerName: 'Duration', type: 'number',width: 90,},
          { field: 'status', headerName: 'Status', width: 130 }],
        promoColumns : [
          { field: 'id', headerName: 'ID', width: 70 },
          { field: 'promoTarget', headerName: 'Promo Target', width: 130 },
          { field: 'promoDetails', headerName: 'Details', width: 130 },
          { field: 'promoPreference', headerName: 'Preference', width: 130 },
          { field: 'promoDuration', headerName: 'Duration', type: 'number', width: 90 },
          { field: 'status', headerName: 'Status',width: 130,}],
        eventRows : [],
        promoRows : [],
        data : [],
        display : ''
    };
    // The bind() method creates a new function that, when called, has its 'this' keyword set to the provided value, 
    // with a given sequence of arguments preceding any provided when the new function is called.
    this.changeRows = this.changeRows.bind(this);
    this.handleOptionChange = this.handleOptionChange.bind(this);
    this.onSubmit = this.onSubmit.bind(this);
  }

  componentDidMount() {
    fetch('http://localhost:3001/events/all')
        .then(function(res) {
          return res.json();
      }).then((json)=> {
          this.setState({
          data: json
          })
      });
      this.changeRows()
  }

  changeRows = () => {
    var eventRow = [{ id: 1, eventName: 'New Year', eventDesc: 'Celebrated each year', eventSponsor: 'Ministery', eventPreference: 'Celebrations', eventDuration: 12, status: 'Pending'}];
    var promoRow = [{ id: 1, promoTarget: 'National flies', promoDetails: 'Valid only for residents', promoPreference: 'Turism', promoDuration: '7', status: 'Pending'}];
    this.setState({eventRows: eventRow})
    this.setState({promoRows : promoRow})
   
    return this.state.eventRows
  }

  handleOptionChange = (event) => {
     event.preventDefault();
     this.setState({display : event.target.value})
  }

  onSubmit = () =>{

    this.state.data.map((e) => {return console.log(e.name)})
  }

  render (){
    return (
      <div>
        <div  className="form-body">
          <select className="form-control" value={this.state.display} onChange={this.handleOptionChange}>
            <option>Seleccione la publicación a revisar</option>
            <option>Eventos</option>
            <option>Promociones</option>
          </select>
        </div>
        <div>
          {this.state.display==='Eventos' && // if it's true return the actual JSX
          <div className="form-group">
            <label> Revisar eventos </label>
            <DataGrid
              rows={this.state.eventRows}
              columns={this.state.eventColumns}
              pageSize={5}
              rowsPerPageOptions={[5]}
              checkboxSelection
              style={{ height: 400, width: '100%', background: "white", marginLeft: "auto", marginRight: "auto"}}
            />
          </div>
          }
        </div>
        <div>
          {this.state.display==='Promociones' && // if it's true return the actual JSX
          <div className="form-group">
            <label> Revisar Promociones </label>
            <DataGrid
              rows={this.state.promoRows}
              columns={this.state.promoColumns}
              pageSize={5}
              rowsPerPageOptions={[5]}
              checkboxSelection
              style={{ height: 400, width: '80%', background: "white", marginLeft: "auto", marginRight: "auto"}}
            />
          </div>
          }
        </div>
        <button type="button" onClick={this.onSubmit}>Imprimir input</button>
      </div>
    )
  }
}

export default Body