/*-Publisher.js-*/

import "./../styles/generic.css";
import React from "react";
import Form from "./publisherForm";
import { formData } from "./publisherFormData";

// Builds the Form depending on the publisherFormData file contents passed as props
export default function Publisher() {
  return (
    <div className="App" /* I'd like to change it to "Publisher" but this way the page remains centered*/>
      <Form formData={formData} />
    </div>
  );
}