# Back-End Formulario de Registro

>Based on the tutorials provided by the teacher *Eduardo Diaz*, where we create a RESTFul API using the **PERN** Stack: Postgresql, Express, React and Node.

### Connection to the BBDD is succesful and all CRUD functions are operative.

- "Dynamic" table in sql query (https://stackoverflow.com/questions/50399704/nodejs-variable-substitution-for-table-in-sql-query)

Many other functions and methods were obtained from https://stackoverflow.com/ and the order of the code in general was motivated by *Ernesto Oropeza* (Cinetica Consulting Contact) and the assignature's teacher.