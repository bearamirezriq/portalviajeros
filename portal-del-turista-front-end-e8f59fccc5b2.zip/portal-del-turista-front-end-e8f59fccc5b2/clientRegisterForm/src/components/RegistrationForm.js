/*-RegistrationForm.js-*/

import './../styles/generic.css';
import Header from './registrationFormHeader';
import Body from './registrationFormBody'
import React, { Fragment } from "react";

// Registration Form with its components
function RegistrationForm(props) {
  return (
    <Fragment>
      <div className="RegistrationForm">
        <Header rol={props.rol}/>
        <Body rol={props.rol}/>
      </div>
    </Fragment>
  );
}

export default RegistrationForm;