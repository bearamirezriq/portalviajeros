import React, { Fragment } from "react"
import '../src/css/App.css';


import Login from "./components/Login";

const App = () => {
  return (
    <Fragment>
       <div className="container">
          <Login />
        </div>
    </Fragment>
  );
}

export default App;