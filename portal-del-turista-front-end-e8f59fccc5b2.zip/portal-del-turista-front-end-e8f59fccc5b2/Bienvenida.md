# Bienvenida al repositorio

# **Documento dado de baja debido al avanze continuo del proyecto**

## Introducción BitBucket

BitBucket va a contener nuestro repositorio remoto donde manejaremos todos nuestros archivos, este presenta todas las funcionalidades que GitHub ofrece para el manejo de los archivos. Desde Jira pueden ir al menú de la izquierda y presionar Code para acceder a BitBucket, o bien desde el link que les he compartido.

Para utilizar Bitbucket podemos realizar la conexión con VSCode instalando su extensión, o bien podemos utilizar SourceTree, el cual recomiendo enormemente ya que además de permitir realizar las operaciones de transporte de archivos, este posee un historial completo de cada pull, push, commit, etc. Solo requiere conectarse a Bitbucket para operar (Realizaré un pequeño tutorial para su presentación)

![img][algo]

[algo]: https://i.stack.imgur.com/MgaV9.png



--------------------------------------------

# <center>El modelo PERN</center>

>El Modelo PERN se compone de **PostgreSQL, Express, React y Node.js**. Al combinar estas tecnologías, se puede crear una aplicación web Full-Stack con operaciones CRUD (**create, read, update, and delete**).
--------------------------------------------

## Introducción PostgreSQL

PostgreSQL es un potente sistema de gestión de bases de datos **relacionales de objetos** con énfasis en la extensibilidad y el cumplimiento de estándares que utilizan y amplían el lenguaje SQL.
Se caracteriza por su gran versatilidad, estabilidad y seguridad.


## <center>Crear una tabla</center>
```SQL
CREATE TABLE test
(
    first INT,
    sec_ond VARCHAR(255),
    th1rd VARCHAR,
    fourth INT NOT NULL UNIQUE,

    PRIMARY KEY (first),
    FOREIGN KEY (sec_ond) REFERENCES table2(sec_ond)
);
```

En esta tabla se agregaron 4 filas, cada una con sus caracteristicas y tipo de variable, veamos lo que representa cada cada:

    INT: Variable numérica

    VARCHAR: Variable para Strings

    NOT NULL/NULL: Define si la variable puede o no ser nula

    UNIQUE: Cada elemento es único / no hay elementos duplicados

Al final de la creación se asignó una **PRIMARY KEY** y una **FOREIGN KEY**

- La **PRIMARY KEY** corresponde a la fila

- La **FOREIGN KEY** corresponde 

## <center>Tabla de querys</center>

Para seleccionar elementos de una tabla utilizamos SELECT, el cual especifica las columnas a retornar y FROM especifica la tabla que utilizaremos
```sql  
SELECT sec_ond FROM test;
```
Para retornar todos los elementos de la tabla `test` utilizamos el símbolo de asterisco (`*`)
```sql  
SELECT * FROM test;
```
Para insertar elementos en una tabla se debe tener en consideración el orden de las columnas creadas, de modo que cada elemento a agregar coincida con la variable permitida por su columna:
```sql  
INSERT INTO test VALUES(INT,VARCHAR(255),VARCHAR,INT NOT NULL UNIQUE);
```
Con esto en consideración un ejemplo de INSERT en la tabla  `test` sería:
```sql  
INSERT INTO test VALUES(123,'Segundo elemento','Tercer Elemento',1337);
```

--------------------------------------------

## Introducción Express.js

Express es un framework de aplicación web para Node.js. Al ser un software libre y abierto, se utiliza para construir aplicaciones web y especialmente APIs. Express proporciona una capa delgada de funciones de aplicaciones web fundamentales, sin oscurecer las funciones de Node.js que ya conocemos.

En el siguiente ejemplo levantaremos un servidor en el puerto local 3000 y desplegaremos el mensaje "Hello World"

```javascript
// Ejemplo "Hello World"

const express = require('express')
const app = express()
const port = 3000

app.get('/', (req, res) => {
res.send('Hello World!')
})

app.listen(port, () => {
console.log(`Example app listening on port ${port}`)
})
```
--------------------------------------------

## Introducción React

ReactJS is JavaScript library used for building reusable UI components. According to React official documentation, following is the definition −

React is a library for building composable user interfaces. It encourages the creation of reusable UI components, which present data that changes over time. Lots of people use React as the V in MVC. React abstracts away the DOM from you, offering a simpler programming model and better performance. React can also render on the server using Node, and it can power native apps using React Native. React implements one-way reactive data flow, which reduces the boilerplate and is easier to reason about than traditional data binding.

React Features
JSX − JSX is JavaScript syntax extension. It isn't necessary to use JSX in React development, but it is recommended.

Components − React is all about components. You need to think of everything as a component. This will help you maintain the code when working on larger scale projects.

Unidirectional data flow and Flux − React implements one-way data flow which makes it easy to reason about your app. Flux is a pattern that helps keeping your data unidirectional.

License − React is licensed under the Facebook Inc. Documentation is licensed under CC BY 4.0.

[TutorialsPoint](https://www.tutorialspoint.com/reactjs/reactjs_overview.htm#:~:text=React%20is%20a%20library%20for,programming%20model%20and%20better%20performance.)

--------------------------------------------

## Introducción Node.js

Node.js is a software platform for scalable server-side and networking applications. Node.js applications are written in JavaScript and can be run within the Node.js runtime on Mac OS X, Windows, and Linux without changes.

Node.js applications are designed to maximize throughput and efficiency, using non-blocking I/O and asynchronous events. Node.js applications run single-threaded, although Node.js uses multiple threads for file and network events. Node.js is commonly used for real-time applications due to its asynchronous nature.

Node.js internally uses the Google V8 JavaScript engine to execute code; a large percentage of the basic modules are written in JavaScript. Node.js contains a built-in, asynchronous I/O library for file, socket, and HTTP communication. The HTTP and socket support allows Node.js to act as a web server without additional software such as Apache.

[Wikipedia](wikipedia.org/wiki/Node.js)

--------------------------------------------

## Sección de guía para usar Markdown

_Ver código fuente para mayor detalle_

```
Similar a LaTeX, Markdown es un formato especializado para la escritura con formatos especiales, ideal para la creación de reportes
```

_This_ is a **certified** markdown **_file_**

This document is based in the [markdown](https://markdownguide.org/) format. 

Everything was searched in [https://google.com/][Google]

![ejemplo][image]

[image]: https://fileinfo.com/img/ss/sm/png_79.png

(Example of image insertion)

