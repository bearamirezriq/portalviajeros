# Front-End Formulario Registro

>Based on the tutorials provided by the teacher *Eduardo Diaz*, where we create a RESTFul API using the **PERN** Stack: Postgresql, Express, React and Node.

- Registration form obtained from [Anubhav Bansal](https://www.section.io/engineering-education/registration-form-react.js-firebase/)
- Dependant Dropdown of countries, states and cities obtained from [Cairocoders](https://tutorial101.blogspot.com/2021/11/reactjs-dependent-dropdown-country.html)
- Regex that allows only alphabet in certain inputs obtained from [Borislav Hadzhiev](https://bobbyhadz.com/blog/react-input-only-letters)
- Regex that allows only email format obtained from [Nikita Gourevitch](https://www.codegrepper.com/code-examples/javascript/check+if+the+email+is+valid+react+)
- Landing page example obtained from [devserkan](https://stackoverflow.com/questions/51849063/linking-to-other-components-with-react-router)
- Dynamic page with conditional routes obtained from [Aaron Powell](https://www.aaron-powell.com/posts/2020-12-10-dynamic-forms-with-react-hooks/)
- Data-table example obtained from [MUI](https://mui.com/material-ui/react-table/)

This Registration Form is composed of a Functional Component as Parent with a Child Class Component.

Many other functions and methods were obtained from https://stackoverflow.com/ and the order of the code in general was motivated by *Ernesto Oropeza* (Cinetica Consulting Contact) and the assignature's teacher.