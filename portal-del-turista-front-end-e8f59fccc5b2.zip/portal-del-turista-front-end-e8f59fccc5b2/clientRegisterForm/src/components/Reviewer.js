/*-Reviewer.js-*/

import './../styles/generic.css';
import React, { Fragment } from "react";
import Layout from './reviewerLayout';
import Body from './reviewerBody'

function Reviewer(props) {
  return (
    <Fragment>
      <div className="Reviewer">
        <Layout>
            <Body/>
        </Layout>
      </div>
    </Fragment>
  );
}

export default Reviewer;