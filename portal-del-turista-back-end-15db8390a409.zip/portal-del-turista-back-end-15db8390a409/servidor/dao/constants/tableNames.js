// pg modules doesn't allow dynamic table names, so we have to concadenate the table name to the query
// Storage of all our tables names
module.exports = [
    'users',
    'countries', 
    'states',
    'cities',
    'events',
    'promotions'
]